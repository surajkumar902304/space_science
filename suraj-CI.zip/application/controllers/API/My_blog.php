<?php
// application/controllers/API/My_blog.php
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH.'libraries/REST_Controller.php';

class My_blog extends REST_Controller {

    public function __construct() {

        parent::__construct();
        $this->load->model('Blog_model');

    }


    public function index_get($blog_id = null) {
        if ($blog_id) {
            // Check if the blog exists
            $isBlogExist = $this->Blog_model->numRows('blogs', array('blog_id' => $blog_id));
            
            if ($isBlogExist > 0) {
                // Fetch blog details
                $blogInfo = $this->Blog_model->get_blog('blogs', array('blog_id' => $blog_id));
                
                // Fetch all blogs related to the same user or category
                $blogsData = $this->Blog_model->fetchblogsByIdDesc('blogs', array('user_id' => $blogInfo->user_id));
                
                if (!empty($blogsData)) {
                    $myblogs = array();
    
                    foreach ($blogsData as $od) {
                        $myblogs[] = array(
                            'image' => $od['image'],
                            'title' => $od['title'],
                            'date' => $od['date'],
                            'long_content' => $od['long_content']
                        );
                    }
    
                    // Return the list of blogs
                    $this->response(array(
                        "status" => true,
                        "message" => "My blogs list",
                        "data" => $myblogs
                    ), REST_Controller::HTTP_OK);
                } else {
                    // No blogs found for the user or category
                    $this->response(array(
                        "status" => false,
                        "message" => "No Blogs assigned for this user."
                    ), REST_Controller::HTTP_NOT_FOUND); // Use 404 Not Found for better clarity
                }
            } else {
                // Invalid blog ID
                $this->response(array(
                    "status" => false,
                    "message" => "Invalid Blog ID"
                ), REST_Controller::HTTP_UNAUTHORIZED);
            }
        } else {
            // Blog ID not provided
            $this->response(array(
                "status" => false,
                "message" => "Blog Id required in URL"
            ), REST_Controller::HTTP_BAD_REQUEST); // Use 400 Bad Request for missing parameter
        }
    }
    
}

?>
