<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['jwt_key'] = 'g5d8f9g8erf89sd76f5g84er7g68f4g8re7f6';
$config['jwt_issuer'] = 'http://localhost/suraj-CI/';
$config['jwt_audience'] = 'http://localhost/suraj-CI/';
